---
name: 🚀Feature Request
about: Please describe in detail the features you expect.
title: '[Feature]: Some feature...'
labels: ["enhancement"]
assignees: ''

---

<!-- Please answer these questions before you submit the desired feature. -->

#### 1. Your usage scenarios?

#### 2. What is your expected outcome?