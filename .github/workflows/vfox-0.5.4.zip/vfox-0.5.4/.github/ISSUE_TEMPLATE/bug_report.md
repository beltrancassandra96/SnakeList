---
name: 🐛Bug report
about: Create a report to help us improve
title: '[BUG]: Some problem...'
labels: ["bug"]
assignees: ''

---

**Version**
The version you are currently using
**OS**
macOS、Linux、Windows

**Describe the bug**
A clear and concise description of what the bug is.

**Screenshots[optional]**
If applicable, add screenshots to help explain your problem.
