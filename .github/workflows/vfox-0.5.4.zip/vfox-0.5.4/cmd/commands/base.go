package commands

const CategorySDK = "SDK"
const CategoryPlugin = "Plugin"
